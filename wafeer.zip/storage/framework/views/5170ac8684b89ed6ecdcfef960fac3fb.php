<script src="<?php echo e(asset('front-assets/js/compressed.js')); ?>"></script>
<script src="<?php echo e(asset('front-assets/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('front-assets/js/switcher.js')); ?>"></script>
<?php /**PATH D:\EM_Projects\xampp\htdocs\Laravel\wafeer\resources\views/front/partials/scripts.blade.php ENDPATH**/ ?>