<header class="page_header header_white floating_logo table_section" style="direction: rtl; background-color: #e4f0e8;">
    <div class="container ">
        <div class="row align-items-center">
            <div class="col-md-6 col-xs-12 nowrap">
                <div class="display_table" style="padding: initial;">
                    <a href="/" class="logo logo_image display_table_cell" style="transform: scale(1.5);">
                        <img src="<?php echo e(asset('front-assets/images/logo.png')); ?>" alt=""
                            style="padding-bottom: 10px; float: right;">
                    </a>
                    <div class="logo-meta display_table_cell">
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xs-12 text-right textRight yy" style="padding-left: 100px;">
                <!-- main nav start -->
                <?php echo $__env->make('front.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- eof main nav -->
                <span class="toggle_menu"><span></span></span>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\EM_Projects\xampp\htdocs\Laravel\wafeer\resources\views/front/partials/header.blade.php ENDPATH**/ ?>